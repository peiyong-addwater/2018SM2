/**
 * Created by Martin Valentino on 9/24/16.
 * StudentID : 825178
 */
public class CribbageValuationTest {

    public static void main(String[] args) {
//        String[] arr1 = {"7C","QD","2C","JC","9D"};
//        String[] arr2 = {"AS","3H", "KH", "7H", "KS"};
//        String[] arr3 = {"AS","3D","KH","7H", "2D"};
//        String[] arr4 = {"2S", "3H", "KH", "3S", "4H"};
//        String[] arr5 = {"6C","7C", "8C", "9C", "8S"};
//        String[] arr6 = {"7H","9S", "8C", "7C", "8H"};
//        String[] arr7 = {"5H", "5S", "5C", "JD", "5D"};
//
//        CribbageValuation a = new CribbageValuation(arr1);
//        CribbageValuation b = new CribbageValuation(arr2);
//        CribbageValuation c = new CribbageValuation(arr3);
//        CribbageValuation d = new CribbageValuation(arr4);
//        CribbageValuation e = new CribbageValuation(arr5);
//        CribbageValuation f = new CribbageValuation(arr6);
//        CribbageValuation g = new CribbageValuation(arr7);
//
//        System.out.println("Score arr1: " + a.calculateAtHandCard());
//        System.out.println("Score arr2: " + b.calculateAtHandCard());
//        System.out.println("Score arr3: " + c.calculateAtHandCard());
//        System.out.println("Score arr4: " + d.calculateAtHandCard());
//        System.out.println("Score arr5: " + e.calculateAtHandCard());
//        System.out.println("Score arr6: " + f.calculateAtHandCard());
//        System.out.println("Score arr7: " + g.calculateAtHandCard());
    }


}
